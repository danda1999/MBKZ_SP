package com.example.nakupni_kosik

data class UserModel(var name: String, var LastName: String, var Email: String, var Phone: String, var Password: String)
