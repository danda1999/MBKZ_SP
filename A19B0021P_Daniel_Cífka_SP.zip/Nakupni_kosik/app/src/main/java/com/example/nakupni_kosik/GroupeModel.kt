package com.example.nakupni_kosik

data class GroupeModel(var name: String, var users: String)
